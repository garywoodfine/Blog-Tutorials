using System;

namespace Cms.Attributes
{
    public class TelemetryAttribute : Attribute
    {
        public TelemetryAttribute()
        {
        }
    }
}