namespace Cms.Endpoints
{
    internal static class Routes
    {
        public const string Article = "article";
    }
}