namespace Api.Unit.Tests.EndpointTests.Article.Get
{
    public class HandlerTests
    {
        
    }
}